"""
Combined dashboard for SIH PS 26146.

PS requirement: "Present findings via a simple dashboard or link-analysis
visualization" + "Dashboard/visualization showing flagged entities and
evidence for each flag."

entity_graph.py already gives the link-analysis view, and alerts_explained.csv
already has the per-alert evidence. This script is the "make it one thing a
judge can click through in a demo" step: a single self-contained HTML file
with the alert table (sortable, filterable, shows the SHAP evidence inline)
next to the entity graph, wired together -- click a wallet node in the graph
and the table filters to just that wallet's alerts; click a row in the table
and the graph highlights + centers that wallet.

No build step, no server: everything (alert data, graph nodes/edges) is
embedded as JSON in the page and rendered with vis-network (CDN, same
library pyvis uses under the hood) plus vanilla JS for the table. Opens
directly in a browser, offline-friendly except for the one CDN script tag.

Usage:
    python3 build_dashboard.py
"""
import json

import networkx as nx
import pandas as pd

from entity_graph import (
    ALERTS_PATH, TX_PATH, WALLETS_PATH,
    build_risk_subgraph, build_wallet_graph, load_reason_lookup,
)
from ingest import load_transactions

TIER_COLOR = {
    "high": "#e63946",
    "medium-high": "#f4a261",
    "worth reviewing": "#e9c46a",
    None: "#a8b0b8",
}


def build_graph_payload(G):
    nodes, edges = [], []
    for n, d in G.nodes(data=True):
        tier = d["max_priority_tier"] if d["max_priority_tier"] != "none" else None
        nodes.append({
            "id": int(n),
            "label": f"#{n}",
            "color": TIER_COLOR[tier],
            "size": 14 + 4 * min(d["n_alerts"], 6),
            "borderWidth": 3 if d["is_alerted"] else 1,
            "country": d["country"], "asn": d["asn"], "script_type": d["script_type"],
            "n_alerts": d["n_alerts"], "max_priority_tier": d["max_priority_tier"],
        })
    for u, v, d in G.edges(data=True):
        tier = d["max_priority_tier"]
        edges.append({
            "from": int(u), "to": int(v),
            "color": TIER_COLOR[tier] if tier else "#4a5058",
            "width": 1 + min(d["n_tx"], 8),
            "n_tx": d["n_tx"], "total_btc": round(d["total_btc"], 4),
            "max_priority_tier": tier,
        })
    return nodes, edges


def build_alerts_payload(alerts_path="output/alerts_explained.csv"):
    df = pd.read_csv(alerts_path)
    df = df.sort_values(
        by="priority_tier", key=lambda s: s.map({"high": 0, "medium-high": 1, "worth reviewing": 2})
    )
    cols = ["txid", "canonical_wallet_id", "priority_tier", "xgb_proba", "if_score", "detector", "top_reasons"]
    return df[cols].to_dict(orient="records")


PAGE_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>CyberStrix -- Investigation Dashboard</title>
<script src="https://unpkg.com/vis-network@9.1.9/standalone/umd/vis-network.min.js"></script>
<style>
  :root {
    --bg: #0e1015; --panel: #171a21; --border: #2a2e38; --text: #e8e8ea;
    --dim: #9aa0ac; --high: #e63946; --medhigh: #f4a261; --low: #e9c46a; --none: #a8b0b8;
  }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--text); font-family: -apple-system, Segoe UI, Roboto, sans-serif; }
  header { padding: 14px 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 16px; }
  header h1 { font-size: 16px; margin: 0; font-weight: 600; letter-spacing: 0.3px; }
  header .stat { font-size: 12px; color: var(--dim); }
  .layout { display: flex; height: calc(100vh - 52px); }
  .panel { padding: 12px; overflow: auto; }
  #tablePanel { width: 46%; border-right: 1px solid var(--border); display: flex; flex-direction: column; }
  #graphPanel { width: 54%; position: relative; }
  #network { width: 100%; height: 100%; background: #111318; }
  .toolbar { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
  input[type=text] { background: var(--panel); border: 1px solid var(--border); color: var(--text);
    padding: 6px 10px; border-radius: 6px; font-size: 12px; flex: 1; min-width: 120px; }
  select { background: var(--panel); border: 1px solid var(--border); color: var(--text);
    padding: 6px 8px; border-radius: 6px; font-size: 12px; }
  button.clear { background: #22262f; border: 1px solid var(--border); color: var(--text);
    padding: 6px 10px; border-radius: 6px; font-size: 12px; cursor: pointer; }
  button.clear:hover { background: #2a2e38; }
  table { border-collapse: collapse; width: 100%; font-size: 12px; }
  thead th { position: sticky; top: 0; background: var(--panel); text-align: left; padding: 8px 6px;
    border-bottom: 1px solid var(--border); cursor: pointer; user-select: none; white-space: nowrap; }
  thead th:hover { color: #fff; }
  tbody td { padding: 7px 6px; border-bottom: 1px solid #1e222b; vertical-align: top; }
  tbody tr { cursor: pointer; }
  tbody tr:hover { background: #1b1f28; }
  tbody tr.selected { background: #23283a; }
  .tier { display: inline-block; padding: 2px 7px; border-radius: 10px; font-size: 10px; font-weight: 600; color: #14151a; }
  .tier.high { background: var(--high); color: #fff; }
  .tier.medium-high { background: var(--medhigh); }
  .tier.worth-reviewing { background: var(--low); }
  .reason { color: var(--dim); font-size: 11px; max-width: 320px; }
  .wallet { font-weight: 600; }
  .legend { position: absolute; bottom: 14px; left: 14px; background: rgba(23,26,33,0.9);
    border: 1px solid var(--border); border-radius: 8px; padding: 10px 12px; font-size: 11px; }
  .legend div { display: flex; align-items: center; gap: 6px; margin: 3px 0; }
  .dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; }
  #detail { padding: 10px; border-top: 1px solid var(--border); font-size: 12px; min-height: 60px; color: var(--dim); }
  #detail b { color: var(--text); }
</style>
</head>
<body>
<header>
  <h1>CyberStrix &mdash; Bitcoin Traffic Investigation Dashboard</h1>
  <span class="stat" id="headerStat"></span>
</header>
<div class="layout">
  <div id="tablePanel" class="panel">
    <div class="toolbar">
      <input type="text" id="search" placeholder="Search wallet, txid, or reason...">
      <select id="tierFilter">
        <option value="">All tiers</option>
        <option value="high">High</option>
        <option value="medium-high">Medium-high</option>
        <option value="worth reviewing">Worth reviewing</option>
      </select>
      <button class="clear" id="clearFilter">Clear graph filter</button>
    </div>
    <table id="alertTable">
      <thead>
        <tr>
          <th data-key="canonical_wallet_id">Wallet</th>
          <th data-key="priority_tier">Tier</th>
          <th data-key="xgb_proba">Confidence</th>
          <th data-key="detector">Detector</th>
          <th>Evidence (SHAP)</th>
        </tr>
      </thead>
      <tbody id="alertBody"></tbody>
    </table>
  </div>
  <div id="graphPanel" class="panel">
    <div id="network"></div>
    <div class="legend">
      <div><span class="dot" style="background:var(--high)"></span> High priority</div>
      <div><span class="dot" style="background:var(--medhigh)"></span> Medium-high</div>
      <div><span class="dot" style="background:var(--low)"></span> Worth reviewing</div>
      <div><span class="dot" style="background:var(--none)"></span> Not flagged (counterparty)</div>
    </div>
  </div>
</div>
<div id="detail">Click a wallet node in the graph, or a row in the table, to cross-highlight.</div>

<script>
const ALERTS = __ALERTS_JSON__;
const GRAPH_NODES = __NODES_JSON__;
const GRAPH_EDGES = __EDGES_JSON__;

document.getElementById('headerStat').textContent =
  `${ALERTS.length} alerts across ${GRAPH_NODES.filter(n => n.n_alerts > 0).length} flagged wallets` +
  ` \u2022 ${GRAPH_NODES.length} wallets, ${GRAPH_EDGES.length} links in view`;

// ---------- Graph ----------
const nodesDS = new vis.DataSet(GRAPH_NODES);
const edgesDS = new vis.DataSet(GRAPH_EDGES.map((e, i) => ({...e, id: i, arrows: 'to'})));
const network = new vis.Network(
  document.getElementById('network'),
  { nodes: nodesDS, edges: edgesDS },
  {
    physics: { barnesHut: { gravitationalConstant: -2500, centralGravity: 0.15, springLength: 140 }, stabilization: { iterations: 150 } },
    interaction: { hover: true, tooltipDelay: 100 },
    nodes: { font: { color: '#e8e8ea' } }
  }
);

// ---------- Table ----------
let sortKey = 'priority_tier';
let sortAsc = true;
const tierOrder = { 'high': 0, 'medium-high': 1, 'worth reviewing': 2 };
let graphFilterWallet = null;

function tierClass(t) { return t.replace(/ /g, '-'); }

function renderTable() {
  const search = document.getElementById('search').value.toLowerCase();
  const tierSel = document.getElementById('tierFilter').value;
  let rows = ALERTS.filter(a => {
    if (graphFilterWallet !== null && a.canonical_wallet_id !== graphFilterWallet) return false;
    if (tierSel && a.priority_tier !== tierSel) return false;
    if (search) {
      const hay = `${a.canonical_wallet_id} ${a.txid} ${a.top_reasons}`.toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });
  rows.sort((a, b) => {
    let av = a[sortKey], bv = b[sortKey];
    if (sortKey === 'priority_tier') { av = tierOrder[av]; bv = tierOrder[bv]; }
    if (av < bv) return sortAsc ? -1 : 1;
    if (av > bv) return sortAsc ? 1 : -1;
    return 0;
  });
  const body = document.getElementById('alertBody');
  body.innerHTML = rows.map(a => `
    <tr data-wallet="${a.canonical_wallet_id}" data-txid="${a.txid}">
      <td class="wallet">#${a.canonical_wallet_id}</td>
      <td><span class="tier ${tierClass(a.priority_tier)}">${a.priority_tier}</span></td>
      <td>${(a.xgb_proba * 100).toFixed(1)}%</td>
      <td>${a.detector}</td>
      <td class="reason">${a.top_reasons}</td>
    </tr>
  `).join('');
  [...body.children].forEach(tr => {
    tr.addEventListener('click', () => selectWallet(parseInt(tr.dataset.wallet), tr.dataset.txid));
  });
}

document.querySelectorAll('thead th[data-key]').forEach(th => {
  th.addEventListener('click', () => {
    const key = th.dataset.key;
    if (sortKey === key) sortAsc = !sortAsc; else { sortKey = key; sortAsc = true; }
    renderTable();
  });
});
document.getElementById('search').addEventListener('input', renderTable);
document.getElementById('tierFilter').addEventListener('change', renderTable);
document.getElementById('clearFilter').addEventListener('click', () => {
  graphFilterWallet = null;
  network.unselectAll();
  renderTable();
  document.getElementById('detail').textContent = 'Click a wallet node in the graph, or a row in the table, to cross-highlight.';
});

function selectWallet(walletId, txid) {
  graphFilterWallet = walletId;
  renderTable();
  if (nodesDS.get(walletId)) {
    network.selectNodes([walletId]);
    network.focus(walletId, { scale: 1.2, animation: true });
  }
  const alert = ALERTS.find(a => a.txid === txid) || ALERTS.find(a => a.canonical_wallet_id === walletId);
  if (alert) {
    document.getElementById('detail').innerHTML =
      `<b>Wallet #${alert.canonical_wallet_id}</b> &mdash; tx ${alert.txid} &mdash; ` +
      `<span class="tier ${tierClass(alert.priority_tier)}">${alert.priority_tier}</span> ` +
      `(${(alert.xgb_proba * 100).toFixed(1)}% confidence, ${alert.detector})<br>${alert.top_reasons}`;
  }
}

network.on('click', params => {
  if (params.nodes.length > 0) {
    const walletId = params.nodes[0];
    const firstAlert = ALERTS.find(a => a.canonical_wallet_id === walletId);
    selectWallet(walletId, firstAlert ? firstAlert.txid : null);
  }
});

renderTable();
</script>
</body>
</html>
"""


def main():
    tx_df = load_transactions(TX_PATH)
    wallets_df = pd.read_csv(WALLETS_PATH)
    alerts_df = pd.read_csv(ALERTS_PATH)

    import entity_graph as eg
    eg.alerted_txids = set(alerts_df["txid"])
    eg.tx_tier = dict(zip(alerts_df["txid"], alerts_df["priority_tier"]))

    G, _, _ = build_wallet_graph(tx_df, wallets_df, alerts_df)
    risk_G, alerted = build_risk_subgraph(G, radius=1)

    nodes, edges = build_graph_payload(risk_G)
    alerts_payload = build_alerts_payload()

    html = (
        PAGE_TEMPLATE
        .replace("__ALERTS_JSON__", json.dumps(alerts_payload))
        .replace("__NODES_JSON__", json.dumps(nodes))
        .replace("__EDGES_JSON__", json.dumps(edges))
    )

    out_path = "output/dashboard.html"
    with open(out_path, "w") as f:
        f.write(html)

    print(f"Dashboard: {len(alerts_payload)} alerts, {len(nodes)} wallets, {len(edges)} links")
    print(f"Wrote {out_path} -- open in a browser")


if __name__ == "__main__":
    main()
